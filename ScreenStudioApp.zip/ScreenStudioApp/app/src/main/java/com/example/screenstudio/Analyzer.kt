package com.example.screenstudio

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Local (offline) wallpaper analysis: picks a clock style and a tint that fits the top of the picture. */
object Analyzer {

    /** Crops the bitmap to the given aspect ratio (centered) and scales it to w x h. */
    fun coverCrop(src: Bitmap, w: Int, h: Int): Bitmap {
        val ar = w.toFloat() / h
        val ia = src.width.toFloat() / src.height
        val cw: Int
        val ch: Int
        if (ia > ar) {
            ch = src.height
            cw = (src.height * ar).toInt().coerceIn(1, src.width)
        } else {
            cw = src.width
            ch = (src.width / ar).toInt().coerceIn(1, src.height)
        }
        val x = (src.width - cw) / 2
        val y = (src.height - ch) / 2
        val cropped = Bitmap.createBitmap(src, x, y, cw, ch)
        return Bitmap.createScaledBitmap(cropped, w, h, true)
    }

    fun luminance(color: Int): Float =
        (0.2126f * Color.red(color) + 0.7152f * Color.green(color) + 0.0722f * Color.blue(color)) / 255f

    fun mix(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) * (1 - t) + Color.red(b) * t).toInt().coerceIn(0, 255),
        (Color.green(a) * (1 - t) + Color.green(b) * t).toInt().coerceIn(0, 255),
        (Color.blue(a) * (1 - t) + Color.blue(b) * t).toInt().coerceIn(0, 255)
    )

    /** Average brightness (0..1) of the upper part of the wallpaper, where the clock usually sits. */
    fun topLuminance(src: Bitmap): Float = measure(src).topLum

    /** A tint that harmonizes with the wallpaper and still contrasts with the top area. */
    fun tintFor(src: Bitmap): Int {
        val m = measure(src)
        return chooseColor(m.accent, m.topLum)
    }

    fun chooseColor(accent: Int, bgLum: Float): Int {
        val tint = if (bgLum < 0.55f) mix(accent, Color.WHITE, 0.62f) else mix(accent, Color.BLACK, 0.68f)
        return if (abs(luminance(tint) - bgLum) >= 0.34f) tint
        else if (bgLum < 0.55f) Color.WHITE else Color.BLACK
    }

    fun analyze(src: Bitmap): Look {
        val m = measure(src)
        val style = when {
            m.topEdge > 0.12f -> "bold"
            m.topEdge < 0.04f -> "stack"
            else -> "thin"
        }
        return Look(style, chooseColor(m.accent, m.topLum))
    }

    private class Measure(val topLum: Float, val topEdge: Float, val accent: Int)

    private fun measure(src: Bitmap): Measure {
        val gw = 90
        val gh = 195
        val small = coverCrop(src, gw, gh)
        val px = IntArray(gw * gh)
        small.getPixels(px, 0, gw, 0, 0, gw, gh)
        val lum = FloatArray(gw * gh)
        var ar = 0.0
        var ag = 0.0
        var ab = 0.0
        var aw = 0.0
        for (i in px.indices) {
            val r = Color.red(px[i])
            val g = Color.green(px[i])
            val b = Color.blue(px[i])
            lum[i] = luminance(px[i])
            val mx = max(r, max(g, b))
            val mn = min(r, min(g, b))
            val s = if (mx == 0) 0.0 else (mx - mn).toDouble() / mx
            val v = mx / 255.0
            val wt = s * s * v
            ar += r * wt
            ag += g * wt
            ab += b * wt
            aw += wt
        }
        val rows = (gh * 0.4f).toInt()
        var sumLum = 0f
        var sumEdge = 0f
        var n = 0
        for (y in 0 until rows - 1) {
            for (x in 0 until gw - 1) {
                val k = y * gw + x
                sumLum += lum[k]
                sumEdge += abs(lum[k] - lum[k + 1]) + abs(lum[k] - lum[k + gw])
                n++
            }
        }
        val accent = if (aw > 2.0) {
            var r = (ar / aw).toInt()
            var g = (ag / aw).toInt()
            var b = (ab / aw).toInt()
            val l = (0.2126f * r + 0.7152f * g + 0.0722f * b) / 255f
            if (l < 0.5f) {
                val t = (0.5f - l) * 1.2f
                r += ((255 - r) * t).toInt()
                g += ((255 - g) * t).toInt()
                b += ((255 - b) * t).toInt()
            }
            Color.rgb(r.coerceIn(0, 255), g.coerceIn(0, 255), b.coerceIn(0, 255))
        } else Color.WHITE
        return Measure(sumLum / max(n, 1), sumEdge / max(n, 1), accent)
    }
}
