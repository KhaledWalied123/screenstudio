package com.example.screenstudio

import android.annotation.SuppressLint
import android.app.WallpaperManager
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.ContentValues
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONObject
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null

    private val chooser = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val cb = fileCb
        fileCb = null
        if (uri != null) cb?.onReceiveValue(arrayOf(uri)) else cb?.onReceiveValue(null)
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        web = WebView(this)
        setContentView(web)

        ViewCompat.setOnApplyWindowInsetsListener(web) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            v.setPadding(bars.left, bars.top, bars.right, maxOf(bars.bottom, ime.bottom))
            WindowInsetsCompat.CONSUMED
        }

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.setBackgroundColor(0xFFECEBF3.toInt())
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = callback
                chooser.launch("image/*")
                return true
            }
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
    }

    private fun js(code: String) {
        runOnUiThread { web.evaluateJavascript(code, null) }
    }

    private fun q(s: String): String = JSONObject.quote(s)

    inner class Bridge {

        @JavascriptInterface
        fun screenSize(): String {
            val m = resources.displayMetrics
            return "${m.widthPixels}x${m.heightPixels}"
        }

        @JavascriptInterface
        fun getKey(): String = Prefs.apiKey(this@MainActivity)

        @JavascriptInterface
        fun saveKey(key: String) {
            Prefs.saveApiKey(this@MainActivity, key.trim())
        }

        @JavascriptInterface
        fun askClaude(id: String, prompt: String, b64: String) {
            thread {
                val key = Prefs.apiKey(this@MainActivity)
                val r = AiClient.ask(key, prompt, b64)
                val text = r.getOrNull()
                if (text != null) {
                    js("window.__aiDone(" + q(id) + "," + q(text) + ",'')")
                } else {
                    val msg = r.exceptionOrNull()?.message ?: "خطأ"
                    js("window.__aiDone(" + q(id) + ",'', " + q(msg) + ")")
                }
            }
        }

        @JavascriptInterface
        fun setWallpaper(target: String, b64: String) {
            thread {
                try {
                    val bytes = Base64.decode(b64, Base64.DEFAULT)
                    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        ?: throw IllegalStateException("الصورة تالفة")
                    val flags = when (target) {
                        "home" -> WallpaperManager.FLAG_SYSTEM
                        "lock" -> WallpaperManager.FLAG_LOCK
                        else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
                    }
                    WallpaperManager.getInstance(this@MainActivity).setBitmap(bmp, null, true, flags)
                    js("window.__wpDone(true," + q("تم تغيير الخلفية.") + ")")
                } catch (e: Throwable) {
                    val msg = "ما قدرتش أغيّر الخلفية (" + (e.message ?: "خطأ") + "). جرّب زرار سامسونج."
                    js("window.__wpDone(false," + q(msg) + ")")
                }
            }
        }

        @JavascriptInterface
        fun openSetAs(b64: String) {
            thread {
                try {
                    val bytes = Base64.decode(b64, Base64.DEFAULT)
                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, "screenstudio_" + System.currentTimeMillis() + ".jpg")
                        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ScreenStudio")
                    }
                    val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                        ?: throw IllegalStateException("مقدرتش أحفظ الصورة")
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    val intent = Intent(Intent.ACTION_ATTACH_DATA)
                        .setDataAndType(uri, "image/jpeg")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    runOnUiThread {
                        startActivity(Intent.createChooser(intent, "تعيين كخلفية"))
                    }
                } catch (e: Throwable) {
                    val msg = "ما قدرتش أفتح شاشة التعيين (" + (e.message ?: "خطأ") + ")."
                    js("window.__wpDone(false," + q(msg) + ")")
                }
            }
        }

        @JavascriptInterface
        fun pinClock(style: String, color: Int): String {
            val ctx = this@MainActivity
            val st = if (style in setOf("bold", "stack", "serif", "digital", "round", "duo")) style else "thin"
            Prefs.save(ctx, Look(st, color))
            ClockWidgetProvider.refreshAll(ctx)
            val mgr = AppWidgetManager.getInstance(ctx)
            return if (mgr.isRequestPinAppWidgetSupported) {
                runOnUiThread {
                    mgr.requestPinAppWidget(ComponentName(ctx, ClockWidgetProvider::class.java), null, null)
                }
                "وافق على إضافة الويدجت من الشاشة اللي ظهرت."
            } else {
                "أضف الويدجت يدويًا: اضغط مطولًا على الشاشة الرئيسية ← الويدجت ← رتّب شاشتك."
            }
        }
    }
}
