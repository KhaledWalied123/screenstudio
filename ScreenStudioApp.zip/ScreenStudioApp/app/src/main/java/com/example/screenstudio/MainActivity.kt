package com.example.screenstudio

import android.app.WallpaperManager
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.RadioGroup
import android.widget.TextView
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private var bitmap: Bitmap? = null
    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private lateinit var apiKey: EditText
    private lateinit var target: RadioGroup

    private val pick = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) loadImage(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        preview = findViewById(R.id.preview)
        status = findViewById(R.id.status)
        apiKey = findViewById(R.id.apiKey)
        target = findViewById(R.id.target)
        apiKey.setText(Prefs.apiKey(this))

        findViewById<Button>(R.id.btnPick).setOnClickListener {
            pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        findViewById<Button>(R.id.btnApply).setOnClickListener { applyWallpaper() }
        findViewById<Button>(R.id.btnLocal).setOnClickListener { tuneLocal() }
        findViewById<Button>(R.id.btnAi).setOnClickListener { tuneWithAi() }
        findViewById<Button>(R.id.btnWidget).setOnClickListener { pinWidget() }
    }

    private fun say(text: String) {
        runOnUiThread { status.text = text }
    }

    private fun loadImage(uri: Uri) {
        say("بحمّل الصورة…")
        thread {
            try {
                val bmp = ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri)) { decoder, info, _ ->
                    decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    val longest = maxOf(info.size.width, info.size.height)
                    if (longest > 2400) decoder.setTargetSampleSize((longest / 2400) + 1)
                }
                bitmap = bmp
                runOnUiThread { preview.setImageBitmap(bmp) }
                say("الصورة جاهزة. دوس \"طبّق الخلفية\" أو ظبّط الساعة.")
            } catch (e: Exception) {
                say("معرفتش أفتح الصورة دي. جرّب صورة تانية.")
            }
        }
    }

    private fun applyWallpaper() {
        val bmp = bitmap ?: return say("اختار صورة الأول.")
        val flags = when (target.checkedRadioButtonId) {
            R.id.rHome -> WallpaperManager.FLAG_SYSTEM
            R.id.rLock -> WallpaperManager.FLAG_LOCK
            else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
        }
        say("بطبّق الخلفية…")
        thread {
            try {
                val dm = resources.displayMetrics
                val fitted = Analyzer.coverCrop(bmp, dm.widthPixels, dm.heightPixels)
                WallpaperManager.getInstance(this).setBitmap(fitted, null, true, flags)
                say("تم تغيير الخلفية.")
            } catch (e: Exception) {
                say("ما قدرتش أغيّر الخلفية: ${e.message ?: "خطأ غير معروف"}")
            }
        }
    }

    private fun tuneLocal() {
        val bmp = bitmap ?: return say("اختار صورة الأول.")
        thread {
            val look = Analyzer.analyze(bmp)
            Prefs.save(this, look)
            ClockWidgetProvider.refreshAll(this)
            say("ظبّطت الساعة على الخلفية (شكل: ${styleName(look.style)}). لو ما أضفتش الويدجت لسه، دوس \"أضف ويدجت الساعة\".")
        }
    }

    private fun tuneWithAi() {
        val bmp = bitmap ?: return say("اختار صورة الأول.")
        val key = apiKey.text.toString().trim()
        if (key.isEmpty()) return say("اكتب مفتاح Claude API الأول.")
        Prefs.saveApiKey(this, key)
        say("الذكاء الاصطناعي بيبص على الخلفية…")
        thread {
            val result = AiClient.analyze(key, bmp)
            val ai = result.getOrNull()
            if (ai == null) {
                say("الذكاء الاصطناعي ما نفعش (${result.exceptionOrNull()?.message ?: "خطأ"}). جرّب الظبط بدون إنترنت.")
                return@thread
            }
            val style = if (ai.style in setOf("thin", "bold", "stack")) ai.style else "thin"
            val bg = Analyzer.topLuminance(bmp)
            val aiColor = runCatching { Color.parseColor(ai.colorHex) }.getOrNull()
            val color = if (aiColor != null && kotlin.math.abs(Analyzer.luminance(aiColor) - bg) >= 0.3f) aiColor
            else Analyzer.tintFor(bmp)
            Prefs.save(this, Look(style, color))
            ClockWidgetProvider.refreshAll(this)
            say("${ai.reason}\n${ai.placement}".trim())
        }
    }

    private fun pinWidget() {
        val mgr = AppWidgetManager.getInstance(this)
        if (mgr.isRequestPinAppWidgetSupported) {
            mgr.requestPinAppWidget(ComponentName(this, ClockWidgetProvider::class.java), null, null)
            say("وافق على إضافة الويدجت من الشاشة اللي ظهرت.")
        } else {
            say("أضف الويدجت يدويًا: اضغط مطولًا على الشاشة الرئيسية ← الويدجت ← رتّب شاشتك.")
        }
    }

    private fun styleName(s: String) = when (s) {
        "bold" -> "عريض"
        "stack" -> "مكدّس"
        else -> "خفيف"
    }
}
