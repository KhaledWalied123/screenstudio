package com.example.screenstudio

import android.content.Context
import android.graphics.Color

data class Look(val style: String, val color: Int)

object Prefs {
    private const val FILE = "look"

    fun load(c: Context): Look {
        val p = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        return Look(p.getString("style", "thin") ?: "thin", p.getInt("color", Color.WHITE))
    }

    fun save(c: Context, look: Look) {
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString("style", look.style)
            .putInt("color", look.color)
            .apply()
    }

    fun apiKey(c: Context): String =
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString("apikey", "") ?: ""

    fun saveApiKey(c: Context, key: String) {
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("apikey", key).apply()
    }
}
