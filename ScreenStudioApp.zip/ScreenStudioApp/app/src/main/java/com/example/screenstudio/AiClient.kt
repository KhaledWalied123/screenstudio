package com.example.screenstudio

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Sends the wallpaper image (base64 JPEG) and a prompt to the Claude API and returns the raw text answer. */
object AiClient {
    // Change this if you want a different Claude model.
    const val MODEL = "claude-sonnet-5-5"

    fun ask(apiKey: String, prompt: String, jpegBase64: String): Result<String> = runCatching {
        val image = JSONObject()
            .put("type", "image")
            .put(
                "source", JSONObject()
                    .put("type", "base64")
                    .put("media_type", "image/jpeg")
                    .put("data", jpegBase64)
            )
        val text = JSONObject().put("type", "text").put("text", prompt)
        val message = JSONObject()
            .put("role", "user")
            .put("content", JSONArray().put(image).put(text))
        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 900)
            .put("messages", JSONArray().put(message))

        val conn = (URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 90000
            doOutput = true
            setRequestProperty("content-type", "application/json")
            setRequestProperty("x-api-key", apiKey)
            setRequestProperty("anthropic-version", "2023-06-01")
        }
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val raw = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) error("HTTP $code")
        JSONObject(raw).getJSONArray("content").getJSONObject(0).getString("text")
    }
}
