package com.example.screenstudio

import android.graphics.Bitmap
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

data class AiLook(val style: String, val colorHex: String, val reason: String, val placement: String)

/** Sends the wallpaper to the Claude API and asks for a clock style + color that suits it. */
object AiClient {
    // Change this if you want a different Claude model.
    const val MODEL = "claude-sonnet-5-5"

    private const val PROMPT =
        "You are an expert phone home-screen designer (Samsung One UI). " +
        "The image is the wallpaper of the phone. Pick the clock widget style and color that fit it best.\n" +
        "Styles: \"thin\" = light modern digits; \"bold\" = heavy digits (use for busy or bright wallpapers); " +
        "\"stack\" = huge hours over minutes (use when there is a tall calm area like sky or wall).\n" +
        "clockColor: a #RRGGBB tint pulled from the wallpaper palette (very light on dark areas, very dark on bright areas) " +
        "with strong contrast against the upper part of the picture.\n" +
        "placement: one short sentence telling where to put the clock and widgets on this wallpaper so they avoid the main subject.\n" +
        "Reply with only JSON: {\"clockStyle\":\"thin\",\"clockColor\":\"#RRGGBB\",\"reason\":\"...\",\"placement\":\"...\"}. " +
        "reason and placement must be short sentences in Egyptian Arabic."

    fun analyze(apiKey: String, wallpaper: Bitmap): Result<AiLook> = runCatching {
        val small = Analyzer.coverCrop(wallpaper, 540, 1170)
        val baos = ByteArrayOutputStream()
        small.compress(Bitmap.CompressFormat.JPEG, 80, baos)
        val b64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)

        val image = JSONObject()
            .put("type", "image")
            .put(
                "source", JSONObject()
                    .put("type", "base64")
                    .put("media_type", "image/jpeg")
                    .put("data", b64)
            )
        val text = JSONObject().put("type", "text").put("text", PROMPT)
        val message = JSONObject()
            .put("role", "user")
            .put("content", JSONArray().put(image).put(text))
        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 600)
            .put("messages", JSONArray().put(message))

        val conn = (URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 90000
            doOutput = true
            setRequestProperty("content-type", "application/json")
            setRequestProperty("x-api-key", apiKey)
            setRequestProperty("anthropic-version", "2023-06-01")
        }
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val raw = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) error("HTTP $code")

        val out = JSONObject(raw).getJSONArray("content").getJSONObject(0).getString("text")
        val s = out.indexOf('{')
        val e = out.lastIndexOf('}')
        if (s < 0 || e <= s) error("no json")
        val j = JSONObject(out.substring(s, e + 1))
        AiLook(
            j.optString("clockStyle", "thin"),
            j.optString("clockColor", ""),
            j.optString("reason", ""),
            j.optString("placement", "")
        )
    }
}
