package com.example.screenstudio

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.graphics.Color
import android.widget.RemoteViews

class ClockWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) manager.updateAppWidget(id, build(context))
    }

    companion object {
        fun build(ctx: Context): RemoteViews {
            val look = Prefs.load(ctx)
            val secondary = Color.argb(
                204, Color.red(look.color), Color.green(look.color), Color.blue(look.color)
            )
            return when (look.style) {
                "stack" -> RemoteViews(ctx.packageName, R.layout.widget_clock_stack).apply {
                    setTextColor(R.id.hh, look.color)
                    setTextColor(R.id.mm, secondary)
                    setTextColor(R.id.date, secondary)
                }
                "duo" -> RemoteViews(ctx.packageName, R.layout.widget_clock_duo).apply {
                    setTextColor(R.id.hh, look.color)
                    setTextColor(R.id.mm, secondary)
                    setTextColor(R.id.date, secondary)
                }
                else -> {
                    val layout = when (look.style) {
                        "bold" -> R.layout.widget_clock_bold
                        "serif" -> R.layout.widget_clock_serif
                        "digital" -> R.layout.widget_clock_digital
                        "round" -> R.layout.widget_clock_round
                        else -> R.layout.widget_clock_thin
                    }
                    RemoteViews(ctx.packageName, layout).apply {
                        setTextColor(R.id.time, look.color)
                        setTextColor(R.id.date, secondary)
                    }
                }
            }
        }

        fun refreshAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, ClockWidgetProvider::class.java))
            for (id in ids) mgr.updateAppWidget(id, build(ctx))
        }
    }
}
